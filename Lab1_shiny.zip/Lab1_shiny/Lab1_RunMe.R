## STAT 341: Lab #1 Instructions

# place your cursor at the beginning of each line and hit the "Run" button above

# you should have already installed the shiny package last week, but if you did not
# uncomment the line below by deleting the hashtag ('#') and run it
#install.packages("shiny")
library(shiny)

# before you run this line, make sure you change the file path below
# for example, if you saved the zip file in "Downloads" you would type:
# setwd("~/Downloads")
setwd("replace this text with the path to the uncompressed Lab1_shiny folder")
runApp("Lab1_shiny")
